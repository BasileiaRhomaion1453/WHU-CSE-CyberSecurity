#!/bin/bash

docker-compose stop
docker-compose rm -f 
